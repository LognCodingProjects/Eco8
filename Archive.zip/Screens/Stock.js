import {
  ScrollView,
  StyleSheet,
  Text,
  View,
  TextInput,
  Button,
  Pressable,
} from "react-native";
import React, { useState } from "react";
import { Divider } from "react-native-elements";
import PaintStock from "../Components/PaintStock";
import StockHeader from "../Components/StockHeader";
import SearchStock from "../Components/SearchBox";

const API_KEY = "OO2OADYEAGG4V90D";
const finnhub = require("finnhub");
const api_key = finnhub.ApiClient.instance.authentications["api_key"];
api_key.apiKey = "cfvvpm1r01qmgsjq9l0gcfvvpm1r01qmgsjq9l10";
const finnhubClient = new finnhub.DefaultApi();

// function FetchStock({ symbol }) {
//   const [price, setPrice] = React.useState();
//   const [percent, setPercent] = React.useState();
//   const [amount, setAmount] = React.useState(0);
//   let API_Symbol = symbol;
//   let API_Call =
//     "https://www.alphavantage.co/query?function=TIME_SERIES_DAILY_ADJUSTED&symbol=" +
//     API_Symbol +
//     "&apikey=" +
//     API_KEY;
//   let Xvalues = [];
//   let Yvalues = [];

//   finnhubClient.quote(symbol, (error, data, response) => {
//     if (error) {
//       console.error(error);
//     } else {
//       // fetching the price
//       setPrice(data.c);
//       // fetch & calculating the percentage
//       let percent = ((price - data.pc) / data.pc) * 100;
//       setPercent(Math.round(percent * 100) / 100);
//     }
//   });

//   fetch(API_Call)
//     .then(function (response) {
//       return response.json();
//     })
//     .then(function (data) {
//       for (var key in data["Time Series (Daily)"]) {
//         Xvalues.push(key);
//         Yvalues.push(data["Time Series (Daily)"][key]["2. high"]);
//       }
//     });
//   return (
//     <StockCard
//       symbol={symbol}
//       price={price}
//       percent={percent}
//       amount={amount}
//     ></StockCard>
//   );
// }

// function StockCard(props) {
//   function handleBuy() {
//     // setAmount(amount + 1);
//     alert("Buy");
//   }
//   function handleSell() {
//     // setAmount(amount - 1);
//     alert("Sell");
//   }
//   function handlePress() {
//     // setAmount(amount - 1);
//     alert("Press");
//   }
//   return (
//     <View>
//       <Pressable onPress={handlePress}>
//         <View
//           style={{
//             display: "flex",
//             flexDirection: "row",
//             marginBottom: 15,
//             marginTop: 15,
//           }}
//         >
//           <Text style={{ fontSize: 18, fontWeight: "bold", flex: 1 }}>
//             {" "}
//             {props.symbol}
//           </Text>
//           <View
//             style={{
//               flex: 1,
//               display: "flex",
//               flexDirection: "row",
//             }}
//           >
//             <Text style={{ fontWeight: "bold", fontSize: 16, flex: 1 }}>
//               ${props.price}
//             </Text>
//             <Text
//               style={[
//                 styles.font1,
//                 props.percent > 0 ? { color: "green" } : { color: "red" },
//               ]}
//             >
//               {props.percent}%
//             </Text>
//           </View>
//         </View>
//       </Pressable>
//       <View style={{ height: 0.6, backgroundColor: "#808080" }}></View>
//       {/* <View
//       style={{
//         display: "flex",
//         flexDirection: "row",
//         padding: 10,
//         backgroundColor: "lightblue",
//         borderRadius: 10,
//         margin: 10,
//       }}
//     >
//       <Text style={{ fontSize: 20, fontWeight: "bold" }}>{props.symbol}</Text>
//       <View
//         style={[
//           styles.font1,
//           {
//             alignItems: "flex-end",
//             flex: 1,
//           },
//         ]}
//       >
//         <Text style={styles.font1}>Price: ${props.price}</Text>

//         <Text
//           style={[
//             styles.font1,
//             props.percent > 0 ? { color: "green" } : { color: "red" },
//           ]}
//         >
//           Percent: {props.percent}%
//         </Text>
//         <Text style={styles.font1}>Amount: {props.amount}</Text>
//       </View>
//     </View> */}
//       {/* <View
//       style={{
//         flexDirection: "row",
//         justifyContent: "space-around",
//         marginTop: 10,
//       }}
//     >
//       <Pressable
//         onPress={handleBuy}
//         style={{
//           backgroundColor: "lightblue",
//           padding: 10,
//           borderRadius: 10,
//         }}
//       >
//         <Text>Buy Now</Text>
//       </Pressable>
//       <Pressable
//         onPress={handleSell}
//         style={{
//           backgroundColor: "lightblue",
//           padding: 10,
//           borderRadius: 10,
//         }}
//       >
//         <Text>Sell Now</Text>
//       </Pressable>
//     </View> */}
//     </View>
//   );
// }

const styles = StyleSheet.create({
  card: {
    marginTop: 15,
    backgroundColor: "#f7e5df",
    borderRadius: 10,
  },
  font1: {
    flex: 1,
    fontSize: 16,
    fontWeight: "500",
  },
});

export default function Stock() {
  return (
    <ScrollView>
      <SearchStock></SearchStock>
      <View style={{ marginHorizontal: 10 }}>
        <View style={{ marginBottom: 15, marginTop: 25 }}>
          <Text style={{ fontSize: 21, fontWeight: "bold" }}>
            Most popular stocks
          </Text>
        </View>
        <StockHeader></StockHeader>

        <View style={{ height: "0.1%", backgroundColor: "#808080" }}></View>
        <PaintStock symbol="TSLA"></PaintStock>
        <PaintStock symbol="AMZN"></PaintStock>
        <PaintStock symbol="META"></PaintStock>

        <View style={{ marginBottom: 15, marginTop: 25 }}>
          <Text style={{ fontSize: 21, fontWeight: "bold" }}>
            Top gainers today
          </Text>
        </View>
        <StockHeader></StockHeader>
        <View style={{ height: "0.1%", backgroundColor: "#808080" }}></View>
        <PaintStock symbol="AAPL"></PaintStock>
        <PaintStock symbol="TM"></PaintStock>
        <PaintStock symbol="IBM"></PaintStock>

        <View style={{ marginBottom: 15, marginTop: 25 }}>
          <Text style={{ fontSize: 21, fontWeight: "bold" }}>
            Top losers today
          </Text>
        </View>
        <StockHeader></StockHeader>
        <View style={{ height: "0.1%", backgroundColor: "#808080" }}></View>
        <PaintStock symbol="AAPL"></PaintStock>
        <PaintStock symbol="TM"></PaintStock>
        <PaintStock symbol="IBM"></PaintStock>
      </View>
    </ScrollView>
  );
}
