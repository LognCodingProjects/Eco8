import React from 'react';
import Map from './components/Map';

const App = () => <Map />;

export default App;
